package edu.hm.winf.tutorium.uebung10;

import java.io.PrintWriter;

/*
 * Philosoph als Thread implementiert
 */
public class Philosopher implements Runnable {
	
	Forks forks; // Anzahl Gabeln
	int id; // Identifier f�r den Philosophen
	int maxDishes; // Maximale Anzahl an G�ngen
	PrintWriter out; // Ausgabe-Stream

	/**
	 * Konstruktor f�r Klasse Philosopher
	 */
	public Philosopher(Forks f, int i, int m, PrintWriter o) {
		forks = f;
		id = i;
		maxDishes = m;
		out = o;
	}

	/**
	 * "Lifecycle" eines Philosophen
	 */
	public void run() {

		for (int i = 0; i < maxDishes; i++) {
			doSomeWork(2); // Denken
			forks.take(id); // Gabeln nehmen
			out.println(Thread.currentThread().getName() + " isst den Gang "
					+ (i + 1));
			doSomeWork(2); // Essen
			forks.place(id); // Gabeln zur�cklegen
		}

		out.println(Thread.currentThread().getName() + " fertig");
	}

	// Simulation f�r "Etwas tun"
	// Hier wird nur eine zuf�llige Zeit bis zu max. t Sekunden
	// geschlafen.
	static void doSomeWork(double t) {
		try {
			Thread.sleep((long) (t * 1000.0 * Math.random()));
		} catch (InterruptedException e) {
			System.out.println("doSomeWork: Unterbrechung");
		}
	}
}