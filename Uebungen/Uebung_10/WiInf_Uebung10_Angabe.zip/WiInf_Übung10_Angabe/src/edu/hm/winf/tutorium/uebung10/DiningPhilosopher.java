/**
 * @author Peter Mandl
 * Wirtschaftsinformatik, �bung 10
 *
 * Dieses Programm zeigt eine L�sung f�r das Problem der essenden
 * Philosophen mit n Philosophen. Das Men� enth�lt m G�nge und 
 * es darf nur eine begrenzte Anzahl von Philosophen an den Tisch 
 * (einer weniger als die Gesamtzahl der Philosophen). 
 * Ein Philosoph nimmt immer die Gabeln f�r einen Gang und legt sie danach 
 * wieder zur�ck, um den anderen Kollegen das Essen eines Gangs zu 
 * erm�glichen.
 * 
 * Die Synchronisation erfolgt �ber Semaphore.
 * 
 * Das Programm ist eine abgewandelte Version aus Kredel u.a.: Thread-
 * und Netzwerkprogrammierung mit Java, dpunkt Verlag, 1999
 */
package edu.hm.winf.tutorium.uebung10;

import java.io.*;

public class DiningPhilosopher {
	
	static int philosophers = 5; // Anzahl an Philosophen (kann ver�ndert
									// werden)
	static int dishes = 3; // Anzahl an Men�-G�nge (kann ver�ndert werden)

	// Je Philosoph wird ein Thread erzeugt
	static Thread pt[] = new Thread[philosophers];
	

	public static void main(String[] args) {
		// Main erzeugt lediglich eine Instanz von DiningPhilosopher und
		// lenkt die Ausgabe auf System.out um. Es wird direkt die Methode
		// work aus dieser Klasse aufgerufen.
		new DiningPhilosopher().work(new PrintWriter(System.out, true));
	}

	/**
	 * Die Methode work wickelt die eigentliche Arbeit ab.
	 */
	void work(PrintWriter out) {
		out.println("main gestartet");

		// 5 Gabeln werden verwendet.
		Forks forks = new Forks(philosophers);

		// Philosophen-Threads werden gestartet.
		for (int i = 0; i < philosophers; i++) {
			pt[i] = new Thread(new Philosopher(forks, i, dishes, out));
			pt[i].setName("Philosoph_" + new Integer(i + 1).toString());
			pt[i].start();
			out.println(pt[i].getName() + " gestartet");
		}

		// Auf das Ende der Philosophen-Threads warten.
		for (int i = 0; i < philosophers; i++) {
			try {
				pt[i].join();
			} catch (InterruptedException e) {
				out.println("Unterbrechung");
			}
		}

		out.println("main beendet");
	}
}
