package edu.hm.winf.tutorium.uebung10;


/*
 * Gabeln
 */
class Forks {
	int num; // Anzahl der Gabeln
	MySemaphor[] forkSemaphore; // Semaphore f�r die Nutzung der Gabeln
	MySemaphor tableSemaphore; // Semaphore f�r den Tisch

	/**
	 * Konstruktor
	 */
	public Forks(int n) {
		num = n;
		tableSemaphore = new MySemaphor(num - 1);
		forkSemaphore = new MySemaphor[num];

		for (int j = 0; j < num; j++) {
			forkSemaphore[j] = new MySemaphor(1);
		}
	}

	/**
	 * Zwei Gabeln werden genommen und zwar die links und rechts angeordneten.
	 */
	public void take(int i) {
		tableSemaphore.P(); // Pr�fen, ob am Tisch noch Platz ist
		forkSemaphore[i].P(); // Linke Gabel nehmen
		forkSemaphore[(i + 1) % num].P(); // Rechte Gabel nehmen
	}

	/**
	 * Beide Gabeln zur�cklegen und Tisch verlassen.
	 */
	public void place(int i) {
		forkSemaphore[i].V(); // Linke Gabel zur�cklegen
		forkSemaphore[(i + 1) % num].V(); // Rechte Gabel zur�cklegen
		tableSemaphore.V(); // Tisch verlassen
	}
}