package edu.hm.winf.tutorium.uebung6;
/**
 * Einfaches Object mit einem Z�hler
 */
 
class CounterObject 
{
	private int count = 0;
	
	CounterObject() 
	{
		// Nichts zu konstruieren
	}
	
	void set(int newCount)
	{
		// Kuenstliche Verzoegerung um 0.010 Sek.
		try {
			Thread.sleep(10);
			} 
		catch(Exception x) {}	
		count = newCount;
	}
		
	int get()
	{
		return count;
	}
}
