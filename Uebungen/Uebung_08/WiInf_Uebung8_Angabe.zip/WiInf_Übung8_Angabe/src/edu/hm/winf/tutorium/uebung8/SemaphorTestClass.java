package edu.hm.winf.tutorium.uebung8;

/**
 * 
 * @author Peter Mandl
 * Wirtschaftsinformatik, �bung 9
 * Test einer eigenen Semaphor-Implementierung in Java
 */

import java.lang.Thread;

import edu.hm.winf.tutorium.uebung8.MySemaphor;

/**
 * @author Peter Mandl
 * 
 *         Semaphor-Testklasse
 */
public class SemaphorTestClass {
	public static MySemaphor s1;

	public static void main(String[] args) {
		SemaphorTestClass sem = new SemaphorTestClass();
		sem.work();
	}

	/**
	 * Die Methode work f�hrt die eigentliche Initialisierungsarbeit aus: -
	 * Threads werden gestartet - Das Ende der Threads wird abgewartet
	 */
	void work() {
		s1 = new MySemaphor(1); // Semaphore zur Threadsynchronisation wird
		// angelegt
		
		int maxThreads = 10000; // maximale Anzahl nebenl�ufiger Threads
		Thread tlist[] = new Thread[maxThreads]; // Liste mit Threads

		 System.out.println(Thread.currentThread().getName() +
		 ": Start des Tests");

		for (int i = 0; i < maxThreads; i++) {
			

			try {
				tlist[i] = new Thread(new SemaphorTestThread(s1));
				tlist[i].setName("MyThread_" + new Integer(i + 1).toString());
				tlist[i].start();
				Thread.sleep(10);
				System.out.println(tlist[i].getName() + " gestartet");
			} catch (OutOfMemoryError e) {
				e.printStackTrace();
				System.out.println("Bei "+i+" Threads wurde Exception geworfen und das Programm beendet!");
				System.exit(0);
			}catch (Exception e){
				System.out.println(e);
			}
		}

		/*
		 * Auf das Ende der Threads warten
		 */
		for (int i = 1; i < maxThreads; i++) {

			try {
				tlist[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(Thread.currentThread().getName() +
		 ": Programmende");
	}
}
