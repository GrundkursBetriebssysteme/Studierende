package edu.hm.winf.tutorium.uebung8;

/**
 * @author Peter Mandl
 * Wirtschaftsinformatik, �bung 9
 * Semaphor-Implementierung in Java
 */

/**
 * Semaphor-Klasse, ohne Warteschlange (nicht fair)
 */

class MySemaphor {
	private int max; // Anzahl der maximal m�glichen Threads im kritischen Abschnitt
	private int free; // Anzahl der verf�gbaren Pl�tze im kritischen Abschnitt
	// (so viele Threads d�rfen noch in den kritischen Abschnitt rein)
	
	private int waiting; // Anzahl der in der P-Operation mit wait wartenden
	// Threads (so viele Threads m�chten aktuell in den kritischen Abschnitt rein)

	/**
	 * Konstruktion der Semaphore Bei dieser Art von Konstruktion darf nur ein
	 * Thread in den kritischen Abschnitt
	 */
	public MySemaphor() {
		this(0);
	}

	/**
	 * Konstruktion der Semaphore mit einer Obergrenze Bei dieser Art der
	 * Konstruktion kann man die Anzahl der Threads, die nebenl�ufig im
	 * kritischen Abschnitt sein d�rfen, angeben.
	 */
	public MySemaphor(int i) {
		if (i >= 0) {
			max = i;
		} else {
			max = 0;
		}
		free = max;
		waiting = 0;
	}

	/**
	 * Destruktor
	 */
	protected void finalize() throws Throwable {
		if (max != free) {
			int x = max - free;
			System.out.println("Semaphor: " + x
					+ " Threads h�ngen noch in P()-Operation ");
		}
		super.finalize();
	}

	/**
	 * P-Operation
	 */
	public synchronized void P() {
		while (free <= 0) {
			waiting++; // Anzahl der wartenden Threads erh�hen
			try {
				System.out.println(Thread.currentThread().getName()
						+ " muss in P()-Operation warten");
				System.out.println(Thread.currentThread().getName()
						+ " Es warten derzeit " + waiting + " Threads");
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			waiting--; // Anzahl der wartenden Threads vermindern
			System.out.println(Thread.currentThread().getName()
					+ " in P-Operation(), zur�ck aus wait; es warten derzeit "
					+ waiting + " Threads");
		}
		free--; // Jetzt erst Semaphorez�hler vermindern
	}

	/**
	 * V-Operation
	 */
	public synchronized void V() {
		free++; // Semaphorz�hler erh�hen
		if (waiting > 0) {
			// Nur wenn ein anderer Thread wartet,
			// diesen mit notify benachrichtigen
			System.out
					.println(Thread.currentThread().getName()
							+ " V()-Operation ausgef�hrt, andere Threads d�rfen wieder");
			System.out.println(Thread.currentThread().getName()
					+ " In V()-Operation, es warten derzeit " + waiting
					+ " Threads");
			this.notify();
		}
	}
}