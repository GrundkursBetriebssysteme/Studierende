package edu.hm.winf.tutorium.uebung8;


/**
 * @author mandl
 *         Eigener Thread, der einen kritischen Abschnitt durchl�uft.
 */
class SemaphorTestThread extends Thread {
	MySemaphor s1; // Referenz auf Semaphore

	public SemaphorTestThread(MySemaphor s) {
		s1 = s;
	}

	public void run() {
		// Eintritt in den kritischen Abschnitt, ggf. warten, bis er frei ist.
		s1.P();
		// Beginn des kritischen Abschnitts
		 System.out.println(Thread.currentThread().getName() +
		 " im kritischen Abschnitt");
		try {
			// K�nstliche Verz�gerung um 1 Sekunde
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Ende und Verlassen des kritischen Abschnitts
		 System.out.println(Thread.currentThread().getName() +
		 " verl�sst kritischen Abschnitt");
		s1.V();
	}
}