package edu.hm.winf.tutorium.uebung7;

public class MessageProducer extends Thread {
	
	private MessageBuffer buffer;
	private int loops;
	
	public MessageProducer(int loops) {
		this.buffer = MessageBuffer.getInstance();
		this.loops = loops;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		for (int i = 0; i < loops; i++) {
			try {
				System.out.println(this.getName() + " : Stelle Nachricht #" + i + " ein");
				buffer.putMessage("Text #" + i);
			} catch (InterruptedException e) {
				return;
			}
		}
	}
}
