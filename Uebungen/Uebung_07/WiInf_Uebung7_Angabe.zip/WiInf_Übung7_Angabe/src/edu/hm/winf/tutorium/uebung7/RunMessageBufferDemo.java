package edu.hm.winf.tutorium.uebung7;

public class RunMessageBufferDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int loops = 30;
		MessageProducer p = new MessageProducer(loops);
		MessageConsumer c = new MessageConsumer(loops);

		p.start();
		c.start();
		
		try {
			p.join();
			c.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
