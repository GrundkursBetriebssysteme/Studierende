package edu.hm.winf.tutorium.uebung7;

public class MessageConsumer extends Thread {
	
	private MessageBuffer buffer;
	private int loops;
	
	public MessageConsumer(int loops) {
		this.buffer = MessageBuffer.getInstance();
		this.loops = loops;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		for (int i = 0; i < loops; i++) {
			try {
				String msg = buffer.getMessage();
				System.out.println(this.getName() + " : hole Nachricht '" + msg + "' ab");
			} catch (InterruptedException e) {
				return;
			}
		}
	}
}
