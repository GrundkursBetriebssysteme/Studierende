package edu.hm.winf.tutorium.uebung7;

public class MessageBuffer {
	
	private static MessageBuffer instance = null;
	private String message = null;
	
	public static MessageBuffer getInstance() {
		if (instance == null) instance = new MessageBuffer();
		return instance;
	}
	
	//TODO: Synchronisation des Methodenzugriffs
	public void putMessage(String msg) throws InterruptedException {
		while (!isEmpty()) {
			try {
				//TODO: eine sinnvolle Operation
			} catch (InterruptedException e) {
				throw e;
			}
		}
		message = msg;
		//TODO: eine sinnvolle Operation
	}
	
	//TODO: Synchronisation des Methodenzugriffs
	public String getMessage() throws InterruptedException {
		while (isEmpty()) {
			try {
				//TODO: eine sinnvolle Operation
			} catch (InterruptedException e) {
				throw e;
			}
		}
		String result = message;
		clearBuffer();
		//TODO: eine sinnvolle Operation
		return result;
	}
	
	private boolean isEmpty() {
		return (message == null);
	}
	
	private void clearBuffer() {
		message = null;
	}
}
